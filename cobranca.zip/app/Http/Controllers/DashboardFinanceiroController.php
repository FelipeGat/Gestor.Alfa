<?php

namespace App\Http\Controllers;

use App\Models\Cobranca;
use App\Models\Empresa;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\ContaFinanceira;

class DashboardFinanceiroController extends Controller
{
    public function index(Request $request)
    {
        $empresaId = $request->get('empresa_id');
        $ano = $request->get('ano', now()->year);

        $baseQuery = Cobranca::query()
            ->whereYear('data_vencimento', $ano);

        if ($empresaId) {
            $baseQuery->whereHas(
                'orcamento',
                fn($q) =>
                $q->where('empresa_id', $empresaId)
            );
        }

        /**
         * DADOS AGRUPADOS DO BANCO
         */
        $recebidoPorMes = (clone $baseQuery)
            ->where('status', 'pago')
            ->selectRaw('MONTH(data_vencimento) as mes, SUM(valor) as total')
            ->groupBy('mes')
            ->pluck('total', 'mes')
            ->toArray();

        $previstoPorMes = (clone $baseQuery)
            ->where('status', '!=', 'pago')
            ->selectRaw('MONTH(data_vencimento) as mes, SUM(valor) as total')
            ->groupBy('mes')
            ->pluck('total', 'mes')
            ->toArray();

        // DESPESAS POR MÊS
        $despesaPagaPorMes = \App\Models\ContaPagar::whereYear('data_vencimento', $ano)
            ->where('status', 'pago')
            ->selectRaw('MONTH(data_vencimento) as mes, SUM(valor) as total')
            ->groupBy('mes')
            ->pluck('total', 'mes')
            ->toArray();

        $despesaPrevistaPorMes = \App\Models\ContaPagar::whereYear('data_vencimento', $ano)
            ->where('status', 'em_aberto')
            ->selectRaw('MONTH(data_vencimento) as mes, SUM(valor) as total')
            ->groupBy('mes')
            ->pluck('total', 'mes')
            ->toArray();

        /**
         * MONTA JANEIRO → DEZEMBRO FIXO
         */
        $labels = [];
        $recebido = [];
        $previsto = [];
        $despesaPaga = [];
        $despesaPrevista = [];

        for ($mes = 1; $mes <= 12; $mes++) {
            $labels[]   = Carbon::create()->month($mes)->translatedFormat('M');
            $recebido[] = $recebidoPorMes[$mes] ?? 0;
            $previsto[] = $previstoPorMes[$mes] ?? 0;
            $despesaPaga[] = $despesaPagaPorMes[$mes] ?? 0;
            $despesaPrevista[] = $despesaPrevistaPorMes[$mes] ?? 0;
        }

        /**
         * KPIs
         */
        $totalRecebido = (clone $baseQuery)->where('status', 'pago')->sum('valor');
        $totalPrevisto = (clone $baseQuery)->where('status', '!=', 'pago')->sum('valor');

        $empresas = Empresa::orderBy('nome_fantasia')->get();

        /**
         * SALDOS DAS CONTAS BANCÁRIAS
         */
        $contasFinanceiras = \App\Models\ContaFinanceira::query()
            ->when($empresaId, function ($q) use ($empresaId) {
                $q->where('empresa_id', $empresaId);
            })
            ->orderBy('tipo')
            ->orderBy('nome')
            ->get();

        // Agrupar por tipo
        $contasAgrupadasPorTipo = $contasFinanceiras->groupBy('tipo');

        // Debug temporário
        if (!isset($contasAgrupadasPorTipo)) {
            dd('Variável contasAgrupadasPorTipo não foi criada!');
        }

        // Saldo total apenas de contas correntes
        $saldoTotalBancos = $contasFinanceiras
            ->where('tipo', 'corrente')
            ->sum('saldo');

        $inicio = $request->get('inicio')
            ? Carbon::parse($request->inicio)->startOfDay()
            : now()->startOfMonth()->startOfDay();

        $fim = $request->get('fim')
            ? Carbon::parse($request->fim)->endOfDay()
            : now()->endOfMonth()->endOfDay();

        /**
         * RECEITA / DESPESA REALIZADA
         */
        $receitaRealizada = Cobranca::where('status', 'pago')
            ->whereBetween('pago_em', [$inicio, $fim])
            ->when(
                $empresaId,
                fn($q) =>
                $q->whereHas(
                    'orcamento',
                    fn($oq) =>
                    $oq->where('empresa_id', $empresaId)
                )
            )
            ->sum('valor');

        $despesaRealizada = \App\Models\ContaPagar::where('status', 'pago')
            ->whereBetween('pago_em', [$inicio, $fim])
            ->sum('valor');

        $saldoRealizado = $receitaRealizada - $despesaRealizada;

        /**
         * PREVISTO
         */
        $aReceber = Cobranca::where('status', '!=', 'pago')
            ->whereBetween('data_vencimento', [$inicio, $fim])
            ->when(
                $empresaId,
                fn($q) =>
                $q->whereHas(
                    'orcamento',
                    fn($oq) =>
                    $oq->where('empresa_id', $empresaId)
                )
            )
            ->sum('valor');

        $aPagar = \App\Models\ContaPagar::where('status', 'em_aberto')
            ->whereBetween('data_vencimento', [$inicio, $fim])
            ->sum('valor');

        $saldoPrevisto = $aReceber - $aPagar;

        /**
         * ATRASADOS / PAGOS
         */
        $atrasado = Cobranca::where('status', '!=', 'pago')
            ->whereDate('data_vencimento', '<', now())
            ->when(
                $empresaId,
                fn($q) =>
                $q->whereHas(
                    'orcamento',
                    fn($oq) =>
                    $oq->where('empresa_id', $empresaId)
                )
            )
            ->sum('valor');

        $pago = Cobranca::where('status', 'pago')
            ->whereBetween('pago_em', [$inicio, $fim])
            ->sum('valor');

        $saldoSituacao = $atrasado - $pago;

        return view('dashboard-financeiro.index', [
            'labels' => $labels,
            'recebido' => $recebido,
            'previsto' => $previsto,
            'despesaPaga' => $despesaPaga,
            'despesaPrevista' => $despesaPrevista,
            'totalRecebido' => $totalRecebido,
            'totalPrevisto' => $totalPrevisto,
            'empresas' => $empresas,
            'empresaId' => $empresaId,
            'ano' => $ano,
            'contasFinanceiras' => $contasFinanceiras,
            'contasAgrupadasPorTipo' => $contasAgrupadasPorTipo,
            'saldoTotalBancos' => $saldoTotalBancos,
            'inicio' => $inicio,
            'fim' => $fim,
            'receitaRealizada' => $receitaRealizada,
            'despesaRealizada' => $despesaRealizada,
            'saldoRealizado' => $saldoRealizado,
            'aReceber' => $aReceber,
            'aPagar' => $aPagar,
            'saldoPrevisto' => $saldoPrevisto,
            'atrasado' => $atrasado,
            'pago' => $pago,
            'saldoSituacao' => $saldoSituacao,
        ]);
    }
}
