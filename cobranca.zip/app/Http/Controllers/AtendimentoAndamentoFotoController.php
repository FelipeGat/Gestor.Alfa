<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\AtendimentoAndamento;
use App\Models\AtendimentoAndamentoFoto;

class AtendimentoAndamentoFotoController extends Controller
{
    /**
     * Retorna o caminho base correto para uploads
     */
    private function uploadsBasePath(): string
    {
        // Produção: usa o caminho definido no .env
        // Local: fallback para public/uploads
        return rtrim(
            env('UPLOADS_PUBLIC_PATH', public_path('uploads')),
            '/'
        );
    }

    /**
     * STORE
     */
    public function store(Request $request, AtendimentoAndamento $andamento)
    {
        $user = Auth::user();
        $atendimento = $andamento->atendimento;

        // Técnico só pode anexar no atendimento dele
        if ($user->tipo === 'funcionario') {
            abort_if(
                $atendimento->funcionario_id !== $user->funcionario_id,
                403,
                'Acesso não autorizado.'
            );

            abort_if(
                in_array($atendimento->status_atual, ['finalizacao', 'concluido']),
                403,
                'Não é possível anexar fotos neste status.'
            );
        }

        // Limite de fotos por andamento
        $quantidadeAtual = $andamento->fotos()->count();
        $novasFotos = count($request->file('fotos', []));

        abort_if(
            ($quantidadeAtual + $novasFotos) > 8,
            422,
            'Cada andamento pode conter no máximo 8 fotos.'
        );

        // Validação
        $request->validate([
            'fotos'   => ['required', 'array'],
            'fotos.*' => ['image', 'max:2048'],
        ]);

        $basePath = $this->uploadsBasePath();
        $destino = $basePath . "/andamentos/atendimento_{$atendimento->id}";

        if (!file_exists($destino)) {
            mkdir($destino, 0755, true);
        }

        foreach ($request->file('fotos') as $foto) {

            $nomeArquivo = uniqid() . '.' . $foto->getClientOriginalExtension();

            $foto->move($destino, $nomeArquivo);

            // Caminho RELATIVO (usado pelo asset())
            $path = "uploads/andamentos/atendimento_{$atendimento->id}/{$nomeArquivo}";

            $andamento->fotos()->create([
                'arquivo' => $path,
            ]);
        }

        return back()->with('success', 'Fotos anexadas com sucesso.');
    }

    /**
     * DESTROY
     */
    public function destroy($fotoId)
    {
        $user = Auth::user();

        $foto = AtendimentoAndamentoFoto::with('andamento.atendimento')->findOrFail($fotoId);

        $andamento = $foto->andamento;
        $atendimento = $andamento->atendimento;

        // Técnico só remove se for o responsável
        if ($user->tipo === 'funcionario') {
            abort_if(
                $atendimento->funcionario_id !== $user->funcionario_id,
                403,
                'Acesso não autorizado.'
            );

            abort_if(
                in_array($atendimento->status_atual, ['finalizacao', 'concluido']),
                403,
                'Não é possível remover fotos neste status.'
            );
        }

        // Caminho físico correto do arquivo
        $arquivoFisico = $this->uploadsBasePath() . '/' . $foto->arquivo;

        if (file_exists($arquivoFisico)) {
            unlink($arquivoFisico);
        }

        $foto->delete();

        return back()->with('success', 'Foto removida com sucesso.');
    }
}