<p>Olá, {{ $user->name }}!</p>

<p>
    Seu acesso ao <strong>Portal do Cliente</strong> foi criado.
</p>

<p>
    👉 <a href="{{ $link }}">
        Clique aqui para criar sua senha
    </a>
</p>

<p>
    Após criar sua senha, você poderá acessar seus boletos normalmente.
</p>

<p>
    Atenciosamente,<br>
    <strong>Grupo Soluções</strong>
</p>