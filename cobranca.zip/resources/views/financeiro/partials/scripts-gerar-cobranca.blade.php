{{-- Partial vazio para scripts relacionados à geração de cobrança. --}}
{{-- Criado para evitar erro de "View not found" quando incluído em algumas rotas. --}}

@once
@push('scripts')
{{-- script placeholder --}}
@endpush
@endonce